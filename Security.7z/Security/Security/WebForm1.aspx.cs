﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Security
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            { 
            ListItem selectUser1=new ListItem("Select User","1");
            ListItem security1=new ListItem("Security1","2");
            ListItem security2=new ListItem("Security2","3");
            ListItem admin1=new ListItem("Admin","4");
            Usertype.Items.Add(selectUser1);
            Usertype.Items.Add(security1);
            Usertype.Items.Add(security2);
            Usertype.Items.Add(admin1);
        
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Usertype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}