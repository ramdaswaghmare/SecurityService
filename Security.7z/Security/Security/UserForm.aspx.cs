﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
//using System.Data.SqlClient;
using System.Xml.Linq;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Configuration;
//using System.Data.SqlClient.SqlException;
//using System.Windows.Forms;
//using System.Web.UI.WebControls.CalendarDay;
 
namespace Security
{
    public partial class UserForm : System.Web.UI.Page
    {
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();

        public Nullable<DateTime> Published { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if(!IsPostBack)
            {
                Calendar1.Visible = false;
            }
            else if (MaleRadioButton1.Checked == true)
            {
                //Response.Write(  MaleRadioButton1.Text + "<br/>");
            }
            else if (FemaleRadioButton2.Checked)
            {
                //Response.Write(  FemaleRadioButton2.Text + "<br/>");
            }
            else if(OtherRadioButton3.Checked)
            {
                //Response.Write(  OtherRadioButton3.Text + "<br/>");
            }
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           /* if (!IsPostBack)
            {
                ListItem c1 = new ListItem("City", "1");
                ListItem c2 = new ListItem("Mumbai", "2");
                ListItem c3 = new ListItem("Pune", "3");
                ListItem c4 = new ListItem("Hyderabad", "4");
                ListItem c5 = new ListItem("Chennai", "1");
                ListItem c6 = new ListItem("Benglore", "2");
                ListItem c7 = new ListItem("Dilhi", "3");
                ListItem c8 = new ListItem("Aurangabad", "4");
                City.Items.Add(c1);
                City.Items.Add(c2);
                City.Items.Add(c3);
                City.Items.Add(c4);
                City.Items.Add(c5);
                City.Items.Add(c6);
                City.Items.Add(c7);
                City.Items.Add(c8);
            }  */
        }

        protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

         void clear()
        {
           // Button3.Clear();

        }

        protected void TextBox11_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ValidateDate(object sender, ServerValidateEventArgs e)
        {

        }
        protected void Button4_Click(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox7.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if(Calendar1.Visible)
            { 
                Calendar1.Visible = false;

            }
            else
            {
                Calendar1.Visible = true;


            }
        }

        protected void Calendar1_DayRender(object sender, DayRenderEventArgs e)
        {
            if(e.Day.IsOtherMonth || e.Day.IsWeekend)
            {
                e.Day.IsSelectable = false;
                e.Cell.BackColor = System.Drawing.Color.Purple;
            }
           // Response.Write(e.Day.DayNumberText + "<br/>");
        }
       

        protected void TextBox9_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //string msg = "";
            //string Content = "windows.uload=function(){ alert('";
            //Content += msg;
            //Content += "')";
            //Content +="windows.location'";
            //Content += Request.Url.AbsoluteUri;
            //Content +="'};";
            //ClientScript.RegisterStartupScript(this.GetType(), "Sucsess Massage",Content,true);
            string a;
            a = ConfigurationManager .ConnectionStrings["SecurityConnectionString"].ToString();
            SqlConnection con = new SqlConnection(a);
            //con.Open();
            if(FileUpload1.HasFile)
            {
                Label1.Text = "Please Insert Image.  ";
            }
            else
            {
                int length = FileUpload1.PostedFile.ContentLength;
                byte[] pic = new byte[length];
                FileUpload1.PostedFile.InputStream.Read(pic, 0, length);
                SqlCommand cmd = new SqlCommand("insert into Register" + "(image)values(@image)",con);
                cmd.Parameters.AddWithValue("@Image",pic);
                cmd.ExecuteNonQuery();
                Label1.Text = "Uploaded";
            }
            //Response.Redirect(Request.Url.AbsoluteUri);

       
        }
        public void Reset()
        {
            Response.Redirect(Request.Url.AbsoluteUri);
        }
        protected void Button1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }
    }
}